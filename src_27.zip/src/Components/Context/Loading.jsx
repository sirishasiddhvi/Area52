import React from 'react';

export default function Loading(props){
    return(
        <div style={{paddingTop: '200px',}}>
            <center>Loading.....!</center>
        </div>
    )
}